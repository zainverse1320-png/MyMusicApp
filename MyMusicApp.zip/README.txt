My Music App
============
This starter app opens the two requested music websites:
- https://www.deluxesaloon.space/
- https://busdriver.wtf/

IMPORTANT:
This is a WebView wrapper. It does NOT extract or download YouTube audio.
Background/lock-screen playback is dependent on the embedded player and Android/WebView behavior.
A guaranteed native lock-screen player requires an authorized direct audio/stream source and Android Media3 MediaSession integration.
