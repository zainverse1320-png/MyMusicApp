package com.mymusic.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = true
        web.settings.userAgentString = web.settings.userAgentString + " MyMusicApp/1.0"

        findViewById<android.widget.Button>(R.id.deluxe).setOnClickListener {
            web.loadUrl("https://www.deluxesaloon.space/")
        }
        findViewById<android.widget.Button>(R.id.busdriver).setOnClickListener {
            web.loadUrl("https://busdriver.wtf/")
        }

        web.loadUrl("https://www.deluxesaloon.space/")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
